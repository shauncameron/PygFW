# PygFW
PygFW short for Pygame Framwork is a framework I made whist working on Knights and Fables, a pygame project, for school. I wanted to make it into a library so that other people could use it
